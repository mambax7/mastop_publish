<?php

/*
 * Reverses the action of the transifex.php script, ie. it looks for language files in a 
 * /modules/transifex folder, removes the prepended module-language- string in the file name and
 * copies them back into the right modules, creating translation directories where required. 
 * 
 * Place this script in the /modules folder of your website and run it. Remove it after use.
 *
*/

// Check that the script is running from the /modules directory
if (basename(dirname(__FILE__)) == 'modules')
{
	// Initialise
	$module_prefix = $language_prefix = '';
	$file_list = $module_list = array();

	// Check that a /modules/transifex directory is present
	$transifex_path = './transifex/';
	$directory_exists = FALSE;
	if (!is_dir($transifex_path)) {
		echo 'Error: You must place your translation files in /modules/transifex to copy them back 
			out to your modules';
	}

	// Whitelist conventional language file names - only these files will be modified
	$whitelist = array(
		'admin.php',
		'blocks.php',
		'common.php',
		'main.php',
		'modinfo.php',
		'plugins' // Used in the system module
	);

	// Blacklist files we definitely don't want to handle
	$blacklist = array(
		'.',
		'..',
		'index.php',
		'index.html',
		'protector', // Protector does not have language files in the modules directory
		'transifex'
	);

	// Get a whitelist of module directories
	$file_list = scandir('.');
	foreach ($file_list as $filename) {
		if (is_dir($filename) && !in_array($filename, $blacklist)) {
			$module_list[] = $filename;
		}
	}

	// Iterate through the module/transifex files, restoring the original file name and copying to relevant module
	if ($handle = opendir('./transifex')) {
		while (false !== ($entry = readdir($handle))) {
			// Explode the file name using - as the delimiter;
			$filename_components = explode('-', $entry);
			
			// Only work on files that follow the naming convention and have valid module/filename components
			if (count($filename_components) == 3 
					&& in_array($filename_components[0], $module_list) 
					&& in_array($filename_components[2], $whitelist)) {
				
				// Check the required translation directory exists, and make one if necessary
				$translation_directory_exists = $writeable = TRUE;
				$translation_path = './' . $filename_components[0] . '/language/' . $filename_components[1];
				if (!is_dir($translation_path)) {
					$directory_exists = mkdir($translation_path, 0777);
					if (!$directory_exists) {
						echo 'Failed to create translation directory: /' 
						. $filename_components[0] . '/' 
						. $filename_components[1];
					} else {
						// Add an index file to prevent lookups
						$index_path = $translation_path . '/index.html';
						$index_handle = fopen($index_path, 'wb');
						$result = fwrite($index_handle, '<script>history.go(-1);</script>');
						fclose($index_handle);
						chmod($index_path, 0644);
					}
				}
				
				// Copy the file out to the appropriate module/language/ directory
				$source = './transifex/' . $entry;
				$destination = './' . $filename_components[0] . '/language/' 
						. $filename_components[1] . '/' 
						. $filename_components[2];
				$result = copy($source, $destination);
				if ($result) {
					echo 'Copied out to: ' . $destination . '<br />';
				} else {
					echo 'FAILED copying out to ' . $destination . '<br />';
				}
			}
		}
		closedir($handle);
	}

	echo '<br />Run complete. If you see no error messages your transifex language files should have been 
		successfully copied back out the the relevant modules. If you do see errors, you may need to 
		check the script permissions.';
	exit;
}
else
{
	echo '<br />Error: This script must be run from the /modules directory';
	exit;
}