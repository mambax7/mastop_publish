<?php

/*
 * Aids management of language files via Transifex. Since Transifex does not understand folder 
 * structures, this script appends module language files with an identifying prefix to prevent file 
 * name clashes. Place this script in the /modules folder of your website and run it. The prefix 
 * follows the pattern:
 *
 * module-lang-filename.php
 * 
 * Remove the script when you have finished.
 *
*/

// Check that the script is running from the /modules directory
if (basename(dirname(__FILE__)) == 'modules')
{
	// Initialise
	$module_prefix = $language_prefix = '';
	$file_list = $module_list = array();

	// Make a transifex directory to dump language files into
	$transifex_path = './transifex/';
	$directory_exists = $writeable = TRUE;
	if (!is_dir($transifex_path)) {
		$directory_exists = mkdir($transifex_path, 0777);
	}

	// Whitelist conventional language file names - only these files will be modified
	$whitelist = array(
		'admin.php',
		'blocks.php',
		'common.php',
		'main.php',
		'modinfo.php',
		'plugins' // Used in the system module
	);

	// Blacklist files we definitely don't want to handle
	$blacklist = array(
		'.',
		'..',
		'index.php',
		'index.html',
		'protector', // Protector does not have language files in the modules directory
		'transifex'
	);

	// Get a list of module directories
	$file_list = scandir('.');
	foreach ($file_list as $filename) {
		if (is_dir($filename) && !in_array($filename, $blacklist)) {
			$module_list[] = $filename;
		}
	}

	// Iterate through the module directories
	foreach ($module_list as $module)
	{
		// Get a list of translation directories for this module
		$translation_list = array();
		$file_list = scandir('./' . $module . '/language');
		foreach ($file_list as $filename) {
			$path = './' . $module . '/language/' . $filename;
			if (is_dir($path)) {
				if (!in_array($filename, $blacklist)) {
					$translation_list[] = $filename;
				}
			}
		}

		// Copy the language files to a transifex folder, and append module/language to file name
		foreach ($translation_list as $translation) {
			$language_files = array();
			$file_list = scandir('./' . $module . '/language/' . $translation);
			foreach ($file_list as $langfile) {
				if (in_array($langfile, $whitelist)) {
					$source = './' . $module . '/language/' . $translation . '/' . $langfile;
					$destination = './transifex/' . $module . '-' . $translation . '-' . $langfile;
					$result = copy($source, $destination);
					if ($result) {
						echo 'Copied out to: ' . $destination . '<br />';
					} else {
						echo 'FAILED copying out to ' . $destination . '<br />';
					}
				}
			}
		}
		echo 'Finished copying language files for: ' . $module . '<br /><br />';
	}
	echo '<br />Run complete. If you see no error messages your module language files should have been 
		successfully copied out to the /modules/transifex folder and renamed. If you do see errors, you 
		may need to check the script permissions.';
	exit;
}
else
{
	echo '<br />Error: This script must be run from the /modules directory';
	exit;
}